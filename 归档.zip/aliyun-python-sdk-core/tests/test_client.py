from __future__ import absolute_import

__author__='alex'

# import os
# import sys
# parentdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# sys.path.insert(0,parentdir)
# from aliyun-python-sdk-core import client
import pytest

# ak = 'test-ak'
# secret = 'test-secret'
# region = 'test-region'
# agent = 'aliyuncli'
# max_retry_num = 3

# class TestClient:
#
# 	@pytest.mark.smoke
# 	def test_client_init(self):
# 		self#initiate client
# 		acs_client = client.AcsClient(ak, secret, region)
# 		assert acs_client
# 		#set up attributes
# 		acs_client.set_user_agent(agent)
# 		acs_client.set_auto_retry(True)
# 		acs_client.set_max_retry_num(max_retry_num)
# 		assert acs_client.get_user_agent() == agent
# 		assert acs_client.get_max_retry_num() == max_retry_num
# 		assert acs_client.get_access_key() == ak
# 		assert acs_client.get_access_secret() == secret
# 		assert acs_client.get_region_id() == region
# 		assert acs_client.is_auto_retry()

